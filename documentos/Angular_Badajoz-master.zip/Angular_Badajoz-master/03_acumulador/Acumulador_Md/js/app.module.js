angular.module("acumulador", [])
