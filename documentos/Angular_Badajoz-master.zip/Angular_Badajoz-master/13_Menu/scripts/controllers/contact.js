'use strict';

/**
 * @ngdoc function
 * @name appModule.controller:ContactCtrl
 * @description
 * # ContactCtrl
 * Controller of the appModule
 */
angular.module('appModule')
  .controller('ContactCtrl', ['$scope', function ($scope) {

  }]);
