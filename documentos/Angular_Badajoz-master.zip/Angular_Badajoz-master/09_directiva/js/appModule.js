
angular.module("appModule", [
    'commonModule'
]);
