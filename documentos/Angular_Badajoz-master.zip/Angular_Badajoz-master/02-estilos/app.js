angular.module("appMain",[
    // Inyeccion de dependencias a otros modulos
]);




